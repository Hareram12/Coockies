﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using ModelInfos;
namespace Cookies.Models
{
    public class BookManagement : DbContext
    {
        public BookManagement(DbContextOptions<BookManagement> options) : base(options)
        {

        }
        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
        }

        public DbSet<ModuleMaster> ModuleMasters { get; set; }
        public DbSet<QuestionMaster> QuestionMasters { get; set; }
        public DbSet<ChoiceMaster> ChoiceMasters { get; set; }
        public DbSet<user_quiz> user_quizs { get; set; }
    }
}
