﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Filters;

namespace Cookies.Models
{
    public class CustomActionFilter : IActionFilter
    {
        public void OnActionExecuting(
        ActionExecutingContext context)
        {
            // do something before the action executes       
            if (context.HttpContext.Request.
            QueryString.Value.Contains("myKey"))
            {
                if (context.Controller is Controller controller)
                {
                    controller.ViewData["myKey"] =
                    "A data from Action filter!!!";
                }
            }

        }
        public void OnActionExecuted(
        ActionExecutedContext context)
        {
            // do something after the action executes
        }
    }
}
