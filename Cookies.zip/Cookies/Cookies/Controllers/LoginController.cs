﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Claims;
using System.Threading.Tasks;
using LogicLayers.BusinessLayer;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Authentication.Cookies;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Filters;
using Microsoft.Extensions.Logging;
using ModelInfos.DemoLoginModel;

namespace Cookies.Controllers
{
    public class LoginController : Controller
    {
        private readonly ILogger<LoginController> _logger;

        public LoginController(ILogger<LoginController> logger)
        {
            _logger = logger;
        }
        //  [Authorize(Roles = ("user,Admin"))]
        public IActionResult Index()
        {
            return View();
        }
       // [Authorize(Roles = ("Admin"))] //comment this line at first for registering Role as Admin
        [HttpGet]
        public IActionResult Register()
        {
            return View();
        }
        [HttpPost]
        public IActionResult Register(LoginModel objLogin)
        {
            LoginBusinessController objLoginController = new LoginBusinessController();

            if (!ModelState.IsValid)
            {
                return View(objLogin);
            }
            objLoginController.GetRegistered(objLogin);
            return RedirectToAction("Index");

        }
       
        public IActionResult Login(string returnUrl = "")
        {
            if (User.Identity.Name != null)
            {
                return RedirectToAction("Index", "Login");
            }
            var info = new LoginModel { ReturnUrl = returnUrl };
            return View(info);

        }
        [HttpPost]
        public async Task<IActionResult> Login(LoginModel objlogin)
        {
            LoginBusinessController objLogincontroller = new LoginBusinessController();



            if (ModelState.IsValid)
            {
                LoginModel objloginInfo1 = objLogincontroller.GetLogin(objlogin);
                if (objloginInfo1 != null)
                {


                    var claims = new List<Claim>
                    {
                        new Claim(ClaimTypes.Name, objloginInfo1.Email),
                        new Claim(ClaimTypes.Role,objloginInfo1.Role),

                    };
                    ClaimsIdentity userIdentity = new ClaimsIdentity(claims, CookieAuthenticationDefaults.AuthenticationScheme);
                    ClaimsPrincipal principal = new ClaimsPrincipal(userIdentity);

                    await HttpContext.SignInAsync(principal);
                    return RedirectToAction("Index", "Login");
                }
                else
                {
                    TempData["UserLoginFailed"] = "Login Failed.Please enter correct credentials";
                    return View();
                }
            }
            else
                return View();
        }
        [HttpGet]
        public async Task<IActionResult> Logout()
        {
            await HttpContext.SignOutAsync();
            return RedirectToAction("Login", "Login");
        }

        //protected override void OnException(ExceptionContext filterContext)
        //{
        //    filterContext.ExceptionHandled = true;

        //    //Log the error!!

        //    //Redirect to action
        //    filterContext.Result = RedirectToAction("Error", "InternalError");

        //    // OR return specific view
        //    filterContext.Result = new ViewResult
        //    {
        //        ViewName = "~/Views/Error/InternalError.cshtml"
        //    };
        //}
    }
}
