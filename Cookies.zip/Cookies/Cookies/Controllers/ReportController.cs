﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Cookies.Models;
using ModelInfos;
using System.Security.Cryptography.X509Certificates;

namespace Cookies.Controllers
{
    public class ReportController : Controller
    {
        BookManagement _dbbookManagement;
        public ReportController(BookManagement bookManagement)
        {
            _dbbookManagement = bookManagement;
        }

        // GET: ReportController
        public ActionResult Index()
        {
           var objlist= _dbbookManagement.QuestionMasters.ToList();

            return View(objlist);
        }
        public ActionResult QuestionList()
        {
            var objlist = _dbbookManagement.QuestionMasters.ToList();
            var ress = (from a in _dbbookManagement.QuestionMasters
                        join b in _dbbookManagement.ChoiceMasters on a.question_id
                        equals b.question_id
                        select new ModelInfos.QuestionAndAnswer
                        { question_id = a.question_id, question = a.question, 
                            choice_id = b.choice_id, choices = b.choices }).ToList();

            return View(objlist);
        }
        public ActionResult QuiezText(int?QuestionId)
        {



           
            if(!QuestionId.HasValue)
            {
                QuestionId = 1;
                ViewBag.QuestionId = QuestionId;
                if (QuestionId.HasValue)
                {
                    ViewBag.QuestionId = 1;

                }
            }
            else
            {
                ViewBag.QuestionId = ++QuestionId;
            }
           

            var ress = (from a in _dbbookManagement.QuestionMasters
                        join b in _dbbookManagement.ChoiceMasters on a.question_id
                        equals b.question_id
                        select new ModelInfos.QuestionAndAnswer
                        {
                            question_id = a.question_id,
                            question = a.question,
                            choice_id = b.choice_id,
                            choices = b.choices
                        }).Where(x => x.question_id == QuestionId).ToList();
           
            return View(ress);
        }


        public ActionResult QuiezSingleText(IEnumerable<ModelInfos.QuestionAndAnswer> questionAndAnswer)
        {
          var item2=  questionAndAnswer.FirstOrDefault();

            return RedirectToActionPermanent("QuiezText", "Report", new { QuestionId = questionAndAnswer.Select(x=>x.question_id) });
         
        }

        // GET: ReportController/Details/5
        public ActionResult Details(int id)
        {
            return View();
        }

        // GET: ReportController/Create
        public ActionResult Create()
        {
            return View();
        }

        // POST: ReportController/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create(IFormCollection collection)
        {
            try
            {
                return RedirectToAction(nameof(Index));
            }
            catch
            {
                return View();
            }
        }

        // GET: ReportController/Edit/5
        public ActionResult Edit(int id)
        {
            return View();
        }

        // POST: ReportController/Edit/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit(int id, IFormCollection collection)
        {
            try
            {
                return RedirectToAction(nameof(Index));
            }
            catch
            {
                return View();
            }
        }

        // GET: ReportController/Delete/5
        public ActionResult Delete(int id)
        {
            return View();
        }

        // POST: ReportController/Delete/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Delete(int id, IFormCollection collection)
        {
            try
            {
                return RedirectToAction(nameof(Index));
            }
            catch
            {
                return View();
            }
        }
    }
}
