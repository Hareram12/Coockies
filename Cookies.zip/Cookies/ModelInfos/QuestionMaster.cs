﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Text;

namespace ModelInfos
{

   public class ModuleMaster
    {
        [Key]
        public int Module_Id { get; set; }
       
        [Required]
        public string Module_Name { get; set; }
    }
    [Table("Questions")]
   public class QuestionMaster
    {
        [Key]
        public int question_id { get; set; }
        [Required]
        public int module_id { get; set; }
        [Required]
        public string question { get; set; }
    }
    public class QuestionAndAnswer
    {
        public int question_id { get; set; }
        public string question { get; set; }
        public string choices { get; set; }
        public int choice_id { get; set; }
        public bool is_correct { get; set; }
    }
    [Table("Choices")]
    public  class ChoiceMaster
    {
        [Key]
        public int choice_id { get; set; }
        [Required]
        public int question_id { get; set; }
        [Required]
        public string choices { get; set; }

        public bool is_correct { get; set; }
    }


 public   class user_quiz
    {
        [Key]
        public Guid userid { get; set; }
        [Required]
        public int Score { get; set; }
        [Required]
        public int total_quizzes_taken { get; set; }

        public int Result { get; set; }
    }
}
