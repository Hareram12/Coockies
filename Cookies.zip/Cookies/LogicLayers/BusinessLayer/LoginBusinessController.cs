﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Security.Cryptography;
using System.Text;
using LogicLayers.DataAcessLayer;
using ModelInfos.DemoLoginModel;

namespace LogicLayers.BusinessLayer
{
    public class LoginBusinessController
    {

        public LoginModel GetLogin(LoginModel objLogin)
        {

            DataAccessProvider objLoginData = new DataAccessProvider();

            LoginModel loginInfo = objLoginData.GetLoginInfoByEmail(objLogin.Email);
            var key = Guid.Parse("7E3C0EF6-66C1-4FC6-916C-14A11ECBFEFE").ToString("N");
            string mat = Decrypt(loginInfo.Password, key).ToString();
            if (objLogin.Email == loginInfo.Email && mat == objLogin.Password)
            {
                return loginInfo;
            }
            return null;
        }

        public List<LoginModel> GetRegistered(LoginModel objRegisterInfo)
        {

            DataAccessProvider objLoginData = new DataAccessProvider();
            List<LoginModel> objloginInfos = new List<LoginModel>();
            var key = Guid.Parse("7E3C0EF6-66C1-4FC6-916C-14A11ECBFEFE").ToString("N");
            objRegisterInfo.Password = Encrypt(objRegisterInfo.Password, key);
            objLoginData.RegisterUser(objRegisterInfo);
            return objloginInfos;
        }

        static string Encrypt(string text, string key)
        {
            var _key = Encoding.UTF8.GetBytes(key);     

            using (var aes = Aes.Create())
            {
                using (var encryptor = aes.CreateEncryptor(_key, aes.IV))
                {
                    using (var ms = new MemoryStream())
                    {
                        using (var cs = new CryptoStream(ms, encryptor, CryptoStreamMode.Write))
                        {
                            using (var sw = new StreamWriter(cs))
                            {
                                sw.Write(text);
                            }
                        }

                        var iv = aes.IV;

                        var encrypted = ms.ToArray();

                        var result = new byte[iv.Length + encrypted.Length];

                        Buffer.BlockCopy(iv, 0, result, 0, iv.Length);
                        Buffer.BlockCopy(encrypted, 0, result, iv.Length, encrypted.Length);

                        return Convert.ToBase64String(result);
                    }
                }
            }
        }

        static string Decrypt(string encrypted, string key)
        {
            var b = Convert.FromBase64String(encrypted);

            var iv = new byte[16];
            var cipher = new byte[16];

            Buffer.BlockCopy(b, 0, iv, 0, iv.Length);
            Buffer.BlockCopy(b, iv.Length, cipher, 0, iv.Length);

            var _key = Encoding.UTF8.GetBytes(key);

            using (var aes = Aes.Create())
            {
                using (var decryptor = aes.CreateDecryptor(_key, iv))
                {
                    var result = string.Empty;
                    using (var ms = new MemoryStream(cipher))
                    {
                        using (var cs = new CryptoStream(ms, decryptor, CryptoStreamMode.Read))
                        {
                            using (var sr = new StreamReader(cs))
                            {
                                result = sr.ReadToEnd();
                            }
                        }
                    }

                    return result;
                }
            }
        }
    }
}
