﻿using System;
using System.Collections.Generic;
using System.Text;

using ModelInfos.DemoLoginModel;
using SQLHelper;

namespace LogicLayers.DataAcessLayer
{
    public class DataAccessProvider
    {
        internal void RegisterUser(LoginModel objLogin)
        {
            List<KeyValuePair<string, object>> parameter = new List<KeyValuePair<string, object>>()
            {

                new KeyValuePair<string, object>("@name",objLogin.Name),
                new KeyValuePair<string, object>("@email",objLogin.Email),
                new KeyValuePair<string, object>("@password",objLogin.Password),
                new KeyValuePair<string, object>("@role",objLogin.Role),

            };
            SQLExecuteNonQuery objSQLH = new SQLExecuteNonQuery();
            List<SQLParam> sQLParam = new List<SQLParam>();
          
            foreach (var item in parameter)
            {
                SQLParam sQLParam1 = new SQLParam();
                sQLParam1.Add(item.Key,item.Value);
                sQLParam.Add(sQLParam1) ;
            }
           
            objSQLH.ExecuteNonQuery("usp_RegisterUser", sQLParam);
        }

        internal LoginModel GetLoginInfoByEmail(string Email)
        {
            List<KeyValuePair<string, object>> parameter = new List<KeyValuePair<string, object>>()
            {
                new KeyValuePair<string, object>("@email",Email)
            };
            SQLExecuteNonQuery SQLH = new SQLExecuteNonQuery();
            List<SQLParam> sQLParam = new List<SQLParam>();

            foreach (var item in parameter)
            {
                SQLParam sQLParam1 = new SQLParam();
                sQLParam1.Add(item.Key, item.Value);
                sQLParam.Add(sQLParam1);
            }
            LoginModel loginInfo = SQLH.ExecuteNonQueryAsGivenType<LoginModel>("usp_Login", sQLParam, "");
            return loginInfo;
        }
    }
}
